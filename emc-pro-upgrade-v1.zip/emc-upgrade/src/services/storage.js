/**
 * EMC Pro — сервис хранилища для renderer.
 *
 * Единый асинхронный API:
 *   - в Electron работает через window.emc.db (SQLite, надёжно);
 *   - в браузере (npm run dev без Electron) — fallback на localStorage,
 *     чтобы разработка UI не требовала main-процесса.
 *
 * Использование:
 *   import { store } from './services/storage';
 *   const rows = await store.list('journal_entries');
 *   await store.insert('journal_entries', { date:'2026-06-12', title:'Блок БП-4', status:'FAIL' });
 */

const hasElectron = typeof window !== 'undefined' && !!window.emc;

// ─── Fallback: localStorage-эмуляция тех же таблиц ──────────────────────────
const LS_PREFIX = 'emcdb:';

function lsRead(table) {
  try { return JSON.parse(localStorage.getItem(LS_PREFIX + table)) || []; }
  catch { return []; }
}
function lsWrite(table, rows) {
  localStorage.setItem(LS_PREFIX + table, JSON.stringify(rows));
}
function lsNextId(rows) {
  return rows.reduce((m, r) => Math.max(m, r.id || 0), 0) + 1;
}

const lsApi = {
  async list(table) {
    return lsRead(table).sort((a, b) => (b.id || 0) - (a.id || 0));
  },
  async get(table, id) {
    return lsRead(table).find(r => r.id === id) || null;
  },
  async insert(table, row) {
    const rows = lsRead(table);
    const rec = {
      ...row,
      id: lsNextId(rows),
      created_at: new Date().toISOString(),
    };
    rows.push(rec);
    lsWrite(table, rows);
    return rec;
  },
  async update(table, id, patch) {
    const rows = lsRead(table);
    const i = rows.findIndex(r => r.id === id);
    if (i === -1) return null;
    rows[i] = { ...rows[i], ...patch, updated_at: new Date().toISOString() };
    lsWrite(table, rows);
    return rows[i];
  },
  async remove(table, id) {
    lsWrite(table, lsRead(table).filter(r => r.id !== id));
    return true;
  },
  async getSetting(key) { return localStorage.getItem(LS_PREFIX + 'set:' + key); },
  async setSetting(key, v) { localStorage.setItem(LS_PREFIX + 'set:' + key, String(v)); return true; },
  async auditTail() { return []; },
  async calibrationSummary() {
    // упрощённая сводка для dev-режима
    const eq = lsRead('equipment');
    const cal = lsRead('calibrations');
    const today = new Date(); const warn = new Date(Date.now() + 30 * 864e5);
    return eq.map(e => {
      const c = cal.filter(c => c.equipment_id === e.id)
        .sort((a, b) => String(b.valid_until).localeCompare(String(a.valid_until)))[0];
      let calib_status = 'missing';
      if (c?.valid_until) {
        const d = new Date(c.valid_until);
        calib_status = d < today ? 'overdue' : d < warn ? 'expiring' : 'actual';
      }
      return { ...e, ...(c || {}), id: e.id, calib_status };
    });
  },
  async importLegacy() { return true; },
};

// ─── Electron: проксирование в main через IPC ───────────────────────────────
const ipcApi = new Proxy({}, {
  get(_t, method) {
    return (...args) => window.emc.db(method, ...args);
  },
});

export const store = hasElectron ? ipcApi : lsApi;
export const isElectron = hasElectron;

// ─── Вспомогательные обёртки верхнего уровня ────────────────────────────────

export const backup = {
  save: () => hasElectron
    ? window.emc.backup.save()
    : Promise.resolve({ ok: false, error: 'Бэкап доступен только в десктоп-версии' }),
  restore: () => hasElectron
    ? window.emc.backup.restore()
    : Promise.resolve({ ok: false, error: 'Восстановление доступно только в десктоп-версии' }),
};

/**
 * Экспорт HTML-протокола в PDF.
 * В Electron — нативный printToPDF с диалогом сохранения.
 * В браузере — открываем окно печати (пользователь выбирает "Сохранить как PDF").
 */
export async function exportProtocolPdf(html, suggestedName) {
  if (hasElectron) return window.emc.protocol.exportPdf(html, suggestedName);
  const w = window.open('', '_blank');
  if (!w) return { ok: false, error: 'Браузер заблокировал всплывающее окно' };
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
  return { ok: true, viaPrintDialog: true };
}

/**
 * Одноразовая миграция старых данных из localStorage приложения в SQLite.
 * Вызвать один раз при старте (после подключения нового хранилища):
 *   migrateLegacyLocalStorage({ journalKey: 'emc_journal', equipmentKey: 'emc_equipment' })
 */
export async function migrateLegacyLocalStorage(keys = {}) {
  if (!hasElectron) return false;
  const done = await store.getSetting('legacy_migrated');
  if (done === '1') return false;
  const read = k => { try { return JSON.parse(localStorage.getItem(k)) || []; } catch { return []; } };
  const payload = {
    journal: keys.journalKey ? read(keys.journalKey) : [],
    equipment: keys.equipmentKey ? read(keys.equipmentKey) : [],
  };
  if (payload.journal.length || payload.equipment.length) {
    await store.importLegacy(payload);
  }
  await store.setSetting('legacy_migrated', '1');
  return true;
}
