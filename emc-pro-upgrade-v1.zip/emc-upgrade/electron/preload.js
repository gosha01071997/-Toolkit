/**
 * EMC Pro — preload: безопасный мост renderer <-> main.
 * В renderer доступно window.emc.*
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('emc', {
  // База данных: window.emc.db('list', 'journal_entries', {...})
  db: (method, ...args) => ipcRenderer.invoke('db', method, ...args),

  backup: {
    save: () => ipcRenderer.invoke('backup:save'),
    restore: () => ipcRenderer.invoke('backup:restore'),
  },

  protocol: {
    exportPdf: (html, name) => ipcRenderer.invoke('protocol:exportPdf', html, name),
  },

  shell: {
    showInFolder: (p) => ipcRenderer.invoke('shell:showInFolder', p),
  },

  version: () => ipcRenderer.invoke('app:version'),
});
