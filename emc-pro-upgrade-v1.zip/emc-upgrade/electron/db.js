/**
 * EMC Pro — слой данных (main-процесс Electron)
 * SQLite через better-sqlite3: схема, миграции, CRUD, бэкап/восстановление, журнал изменений.
 *
 * Зависимость: npm i better-sqlite3
 */
const path = require('path');
const fs = require('fs');
const { app } = require('electron');
const Database = require('better-sqlite3');

let db = null;

// ─── Миграции ────────────────────────────────────────────────────────────────
// Каждая новая версия схемы — новый элемент массива. Никогда не редактируйте
// старые миграции: только добавляйте новые. Версия БД хранится в user_version.
const MIGRATIONS = [
  // v1 — базовая схема
  `
  CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    customer    TEXT DEFAULT '',
    object_name TEXT DEFAULT '',          -- изделие / объект испытаний
    notes       TEXT DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    archived    INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS journal_entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    date        TEXT NOT NULL,             -- ISO YYYY-MM-DD
    title       TEXT NOT NULL,             -- объект / название
    test_type   TEXT DEFAULT '',           -- Radiated Emissions, BCI ...
    standard    TEXT DEFAULT '',
    freq_range  TEXT DEFAULT '',
    level       TEXT DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'WARN' CHECK (status IN ('PASS','FAIL','WARN')),
    problem     TEXT DEFAULT '',
    fix         TEXT DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS equipment (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    station       TEXT DEFAULT '',
    kind          TEXT DEFAULT '',         -- генератор, анализатор, антенна...
    serial        TEXT DEFAULT '',
    inventory_no  TEXT DEFAULT '',
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS calibrations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id  INTEGER NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    cert_no       TEXT DEFAULT '',         -- номер свидетельства о поверке
    issued_at     TEXT,                    -- дата поверки
    valid_until   TEXT,                    -- действительна до
    org           TEXT DEFAULT '',         -- кто поверял
    notes         TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS spectrum_scans (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    journal_id  INTEGER REFERENCES journal_entries(id) ON DELETE SET NULL,
    name        TEXT NOT NULL,
    limit_id    TEXT DEFAULT '',           -- id лимит-линии
    verdict     TEXT DEFAULT '',           -- PASS / FAIL
    points_json TEXT NOT NULL,             -- [[freqHz, dB], ...]
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
  );

  -- Журнал изменений: требование СМК / ГОСТ ISO/IEC 17025
  CREATE TABLE IF NOT EXISTS audit_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    actor     TEXT DEFAULT 'local-user',
    action    TEXT NOT NULL,               -- create / update / delete / backup ...
    entity    TEXT NOT NULL,               -- journal_entries, equipment ...
    entity_id INTEGER,
    details   TEXT DEFAULT ''
  );

  CREATE INDEX IF NOT EXISTS idx_journal_date    ON journal_entries(date DESC);
  CREATE INDEX IF NOT EXISTS idx_journal_status  ON journal_entries(status);
  CREATE INDEX IF NOT EXISTS idx_calib_equipment ON calibrations(equipment_id);
  `,
];

function dbPath() {
  return path.join(app.getPath('userData'), 'emc-pro.sqlite3');
}

function audit(action, entity, entityId, details = '') {
  try {
    db.prepare(
      'INSERT INTO audit_log (action, entity, entity_id, details) VALUES (?,?,?,?)'
    ).run(action, entity, entityId ?? null, String(details).slice(0, 2000));
  } catch (_) { /* журнал не должен ронять операцию */ }
}

function open() {
  if (db) return db;
  db = new Database(dbPath());
  db.pragma('journal_mode = WAL');      // надёжность при сбоях питания
  db.pragma('foreign_keys = ON');

  const current = db.pragma('user_version', { simple: true });
  for (let v = current; v < MIGRATIONS.length; v++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRATIONS[v]);
      db.pragma(`user_version = ${v + 1}`);
      db.exec('COMMIT');
    } catch (e) {
      db.exec('ROLLBACK');
      throw new Error(`Миграция БД v${v + 1} не применилась: ${e.message}`);
    }
  }
  return db;
}

// ─── Универсальный CRUD по белому списку таблиц ─────────────────────────────
const TABLES = new Set([
  'projects', 'journal_entries', 'equipment',
  'calibrations', 'spectrum_scans',
]);

function assertTable(t) {
  if (!TABLES.has(t)) throw new Error(`Недопустимая таблица: ${t}`);
}

const api = {
  open,

  list(table, { where = '', params = [], orderBy = 'id DESC', limit = 1000 } = {}) {
    assertTable(table); open();
    const sql = `SELECT * FROM ${table} ${where ? 'WHERE ' + where : ''} ORDER BY ${orderBy} LIMIT ?`;
    return db.prepare(sql).all(...params, limit);
  },

  get(table, id) {
    assertTable(table); open();
    return db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id) || null;
  },

  insert(table, row) {
    assertTable(table); open();
    const keys = Object.keys(row);
    const sql = `INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`;
    const info = db.prepare(sql).run(...keys.map(k => row[k]));
    audit('create', table, info.lastInsertRowid, JSON.stringify(row).slice(0, 500));
    return api.get(table, info.lastInsertRowid);
  },

  update(table, id, patch) {
    assertTable(table); open();
    const keys = Object.keys(patch);
    if (!keys.length) return api.get(table, id);
    const sql = `UPDATE ${table} SET ${keys.map(k => `${k} = ?`).join(', ')}` +
      (table === 'journal_entries' ? `, updated_at = datetime('now','localtime')` : '') +
      ` WHERE id = ?`;
    db.prepare(sql).run(...keys.map(k => patch[k]), id);
    audit('update', table, id, JSON.stringify(patch).slice(0, 500));
    return api.get(table, id);
  },

  remove(table, id) {
    assertTable(table); open();
    db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
    audit('delete', table, id);
    return true;
  },

  // настройки key-value
  getSetting(key) {
    open();
    const r = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return r ? r.value : null;
  },
  setSetting(key, value) {
    open();
    db.prepare('INSERT INTO settings (key, value) VALUES (?,?) ' +
      'ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, String(value));
    return true;
  },

  auditTail(limit = 200) {
    open();
    return db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?').all(limit);
  },

  // сводка по поверкам: actual / expiring / overdue / missing
  calibrationSummary(daysWarn = 30) {
    open();
    return db.prepare(`
      SELECT e.*, c.cert_no, c.issued_at, c.valid_until,
        CASE
          WHEN c.valid_until IS NULL THEN 'missing'
          WHEN date(c.valid_until) < date('now') THEN 'overdue'
          WHEN date(c.valid_until) < date('now', '+' || ? || ' days') THEN 'expiring'
          ELSE 'actual'
        END AS calib_status
      FROM equipment e
      LEFT JOIN calibrations c ON c.id = (
        SELECT id FROM calibrations WHERE equipment_id = e.id
        ORDER BY date(valid_until) DESC LIMIT 1
      )
      ORDER BY e.station, e.name
    `).all(daysWarn);
  },

  // ─── Бэкап / восстановление одним файлом ─────────────────────────────────
  backupTo(filePath) {
    open();
    db.pragma('wal_checkpoint(TRUNCATE)');
    fs.copyFileSync(dbPath(), filePath);
    audit('backup', 'database', null, filePath);
    return true;
  },

  restoreFrom(filePath) {
    if (db) { db.close(); db = null; }
    // проверим, что это валидная SQLite-база, прежде чем затирать рабочую
    const probe = new Database(filePath, { readonly: true });
    probe.prepare('SELECT 1').get();
    probe.close();
    fs.copyFileSync(filePath, dbPath());
    open();
    audit('restore', 'database', null, filePath);
    return true;
  },

  // одноразовый импорт данных из старого localStorage (вызывается из renderer)
  importLegacy(payload) {
    open();
    const tx = db.transaction(() => {
      for (const e of payload.journal || []) {
        api.insert('journal_entries', {
          date: e.date || new Date().toISOString().slice(0, 10),
          title: e.title || e.project || 'Без названия',
          test_type: e.testType || '', standard: e.standard || '',
          freq_range: e.range || '', level: e.level || '',
          status: ['PASS', 'FAIL', 'WARN'].includes(e.status) ? e.status : 'WARN',
          problem: e.problem || '', fix: e.fix || '',
        });
      }
      for (const eq of payload.equipment || []) {
        api.insert('equipment', {
          name: eq.name || 'Оборудование', station: eq.station || '',
          kind: eq.kind || '', serial: eq.serial || '', inventory_no: eq.inv || '',
        });
      }
    });
    tx();
    audit('import', 'database', null, 'legacy localStorage');
    return true;
  },
};

module.exports = api;
