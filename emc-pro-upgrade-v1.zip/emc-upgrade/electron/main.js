/**
 * EMC Pro — main-процесс Electron (замена старого electron.js)
 * Окно + безопасный IPC: база данных, бэкап/восстановление, экспорт протокола в PDF.
 */
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const db = require('./db');

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 980,
    minHeight: 640,
    title: 'EMC Pro — Инструментарий инженера ЭМС',
    backgroundColor: '#050814',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false, // нужен require в preload; renderer всё равно изолирован
    },
  });

  if (process.env.VITE_DEV_SERVER_URL) {
    win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }

  win.once('ready-to-show', () => { win.show(); win.maximize(); });

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ─── IPC: база данных ───────────────────────────────────────────────────────
// Один канал-диспетчер: проще расширять и логировать.
ipcMain.handle('db', async (_ev, method, ...args) => {
  if (typeof db[method] !== 'function' || method === 'open') {
    throw new Error(`Недопустимый метод БД: ${method}`);
  }
  return db[method](...args);
});

// ─── IPC: бэкап / восстановление с системными диалогами ────────────────────
ipcMain.handle('backup:save', async () => {
  const stamp = new Date().toISOString().slice(0, 10);
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: 'Сохранить резервную копию',
    defaultPath: `emc-pro-backup-${stamp}.sqlite3`,
    filters: [{ name: 'База EMC Pro', extensions: ['sqlite3'] }],
  });
  if (canceled || !filePath) return { ok: false, canceled: true };
  db.backupTo(filePath);
  return { ok: true, filePath };
});

ipcMain.handle('backup:restore', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(win, {
    title: 'Восстановить из резервной копии',
    filters: [{ name: 'База EMC Pro', extensions: ['sqlite3'] }],
    properties: ['openFile'],
  });
  if (canceled || !filePaths[0]) return { ok: false, canceled: true };
  const confirm = await dialog.showMessageBox(win, {
    type: 'warning',
    buttons: ['Восстановить', 'Отмена'],
    defaultId: 1,
    cancelId: 1,
    title: 'Подтверждение',
    message: 'Текущая база будет заменена данными из копии. Продолжить?',
  });
  if (confirm.response !== 0) return { ok: false, canceled: true };
  db.restoreFrom(filePaths[0]);
  return { ok: true };
});

// ─── IPC: экспорт протокола в PDF ───────────────────────────────────────────
// Renderer передаёт готовый HTML протокола; печатаем его в PDF в скрытом окне.
ipcMain.handle('protocol:exportPdf', async (_ev, html, suggestedName = 'protocol.pdf') => {
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: 'Сохранить протокол испытаний',
    defaultPath: suggestedName,
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (canceled || !filePath) return { ok: false, canceled: true };

  const printer = new BrowserWindow({
    show: false,
    webPreferences: { sandbox: true },
  });
  try {
    await printer.loadURL(
      'data:text/html;charset=utf-8,' + encodeURIComponent(html)
    );
    const pdf = await printer.webContents.printToPDF({
      pageSize: 'A4',
      printBackground: true,
      margins: { top: 0.6, bottom: 0.6, left: 0.7, right: 0.5 }, // дюймы; левое поле под подшивку
    });
    fs.writeFileSync(filePath, pdf);
    return { ok: true, filePath };
  } finally {
    printer.destroy();
  }
});

ipcMain.handle('shell:showInFolder', (_ev, p) => shell.showItemInFolder(p));
ipcMain.handle('app:version', () => app.getVersion());

app.whenReady().then(() => {
  db.open();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
