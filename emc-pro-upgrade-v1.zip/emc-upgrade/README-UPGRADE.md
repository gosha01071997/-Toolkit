# EMC Pro — пакет апгрейда v1

Четыре модуля, поднимающие приложение с уровня прототипа до рабочего инструмента лаборатории:

| Модуль | Файлы | Что даёт |
|---|---|---|
| SQLite-хранилище | `electron/db.js`, `electron/main.js`, `electron/preload.js`, `src/services/storage.js` | Надёжная база вместо localStorage: миграции, журнал изменений (audit log), бэкап и восстановление одним файлом, сводка по поверкам |
| Анализатор спектра | `src/features/spectrum/` | Импорт CSV с прибора (drag-n-drop), график с log-осью, лимит-линия, автоматический вердикт PASS/FAIL, таблица превышений, запись в журнал |
| Протокол испытаний | `src/features/protocol/` | Форма протокола по типовой структуре лаборатории, подтягивание СИ с поверками из базы, экспорт в PDF (нативный printToPDF) |
| Command palette | `src/components/CommandPalette.jsx` | Ctrl+K — мгновенный поиск и переход к любому разделу/инструменту |

Все модули без внешних зависимостей в renderer (чистый React + SVG). Единственная новая зависимость — `better-sqlite3` в main-процессе.

---

## Шаг 1. Скопировать файлы

Каталоги `electron/` и `src/` из этого пакета — в корень вашего проекта (рядом со старым `electron.js`). Структура станет:

```
проект/
  electron/
    main.js        ← новый main-процесс (заменяет старый electron.js)
    preload.js
    db.js
  src/
    App.jsx        ← ваш существующий
    main.jsx
    services/storage.js
    features/spectrum/{SpectrumAnalyzer.jsx, limits.js}
    features/protocol/{ProtocolGenerator.jsx, protocolTemplate.js}
    components/CommandPalette.jsx
```

Старый `electron.js` в корне после проверки можно удалить.

## Шаг 2. package.json

```bash
npm i better-sqlite3
npm i -D electron-rebuild
```

Изменить/добавить:

```json
{
  "main": "electron/main.js",
  "scripts": {
    "postinstall": "electron-rebuild -f -w better-sqlite3",
    "electron:dev": "vite build && electron ."
  },
  "build": {
    "files": ["dist/**/*", "electron/**/*", "package.json"]
  }
}
```

`better-sqlite3` — нативный модуль, поэтому нужен `electron-rebuild` (postinstall уже делает это автоматически). В секции `build.files` обязательно добавьте `electron/**/*`, иначе сборка не найдёт main-процесс.

## Шаг 3. Подключить страницы в App.jsx

```jsx
import SpectrumAnalyzer from './features/spectrum/SpectrumAnalyzer';
import ProtocolGenerator from './features/protocol/ProtocolGenerator';
import CommandPalette, { useCommandPalette } from './components/CommandPalette';
import { store, backup, migrateLegacyLocalStorage } from './services/storage';
```

В рендере, рядом с остальными страницами:

```jsx
{page === 'spectrum' && <SpectrumAnalyzer />}
{page === 'protocol' && <ProtocolGenerator />}
```

И два пункта в сайдбар: «Анализатор спектра», «Протоколы».

## Шаг 4. Command palette

Внутри корневого компонента:

```jsx
const palette = useCommandPalette();

const commands = [
  { id:'home',     title:'Главная',                section:'Разделы',     keywords:'home',            action:() => setPage('home') },
  { id:'calc',     title:'Калькуляторы',           section:'Разделы',     keywords:'db dbm vswr',     action:() => setPage('calc') },
  { id:'tests',    title:'Испытания',              section:'Разделы',     keywords:'гост методика',   action:() => setPage('tests') },
  { id:'spectrum', title:'Анализатор спектра',     section:'Инструменты', keywords:'csv график лимит pass fail', action:() => setPage('spectrum') },
  { id:'protocol', title:'Протокол испытаний → PDF', section:'Инструменты', keywords:'отчёт pdf печать', action:() => setPage('protocol') },
  { id:'backup',   title:'Резервная копия базы',   section:'Данные',      keywords:'backup сохранить', action:() => backup.save() },
  { id:'restore',  title:'Восстановить базу из копии', section:'Данные',  keywords:'restore импорт',  action:() => backup.restore() },
  // дальше — по команде на каждый калькулятор: чем больше, тем полезнее Ctrl+K
];

// в JSX, в самом конце разметки:
<CommandPalette {...palette} commands={commands} />
```

## Шаг 5. Перевод данных со старого localStorage (один раз)

При старте приложения:

```jsx
useEffect(() => {
  migrateLegacyLocalStorage({
    journalKey: 'ИМЯ_ВАШЕГО_КЛЮЧА_ЖУРНАЛА',     // как назван ключ в текущем App.jsx
    equipmentKey: 'ИМЯ_КЛЮЧА_ОБОРУДОВАНИЯ',
  });
}, []);
```

Функция сама помечает миграцию выполненной и второй раз ничего не делает.

## Шаг 6. Постепенный переезд журнала и оборудования на store

Новый API (асинхронный, одинаковый в Electron и в браузере):

```js
const entries = await store.list('journal_entries');
await store.insert('journal_entries', { date:'2026-06-12', title:'БП-4', status:'FAIL', problem:'Пик 142 МГц' });
await store.update('journal_entries', id, { fix:'Феррит на CAN-шину' });
await store.remove('journal_entries', id);

// сводка по поверкам для дашборда «Поверка оборудования»:
const summary = await store.calibrationSummary(30); // calib_status: actual | expiring | overdue | missing
```

В браузере (`npm run dev` без Electron) всё это прозрачно работает через localStorage-эмуляцию — UI можно разрабатывать как раньше.

---

## Важно знать

- **Лимит-линии в `limits.js` — демонстрационные.** Структура готова под точные значения: внесите туда уровни из ваших рабочих стандартов (ГОСТ РВ 20.57.306, ГОСТ Р 51317.x) до боевого применения. Пользовательская линия вводится прямо в интерфейсе.
- **Файл базы**: `%APPDATA%/emc-pro/emc-pro.sqlite3` (путь `app.getPath('userData')`). Режим WAL — устойчивость к сбоям питания.
- **Audit log** пишется автоматически на каждые create/update/delete/backup — задел под ГОСТ ISO/IEC 17025. Чтение: `await store.auditTail(200)`.
- **PDF**: в Electron — нативный `printToPDF` с системным диалогом сохранения; в браузере — окно печати («Сохранить как PDF»).

## Что логично делать следующим

1. Перевести существующие журнал/оборудование/поверки на `store` полностью и убрать прямые обращения к localStorage.
2. Распилить App.jsx на `features/*` по образцу этих модулей.
3. Сохранённые сканы (`spectrum_scans`) — отдельная страница «История сканов» с повторным открытием графика.
4. Вставка графика спектра прямо в PDF-протокол (SVG уже есть — сериализовать в шаблон).
5. electron-updater + подпись кода для «взрослой» дистрибуции.
